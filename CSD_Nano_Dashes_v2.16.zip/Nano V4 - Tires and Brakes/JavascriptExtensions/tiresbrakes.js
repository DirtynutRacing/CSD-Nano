/*
 * CSD Nano Dashes - tiresbrakes.js
 * Copyright (c) 2026 DIRTYNUT. All rights reserved.
 *
 * NOT open source. Free for personal, non-commercial use on your own rig only.
 * You may NOT copy, re-upload, redistribute, sell or charge for this file or
 * the dashboards, publish modified or derived versions, or use them to make a
 * competing dashboard. Do not remove this notice.
 * Full terms: LICENSE.txt in the dashboard folder.
 *
 * Provided "as is", without warranty of any kind.
 */
// Conspit CSD Nano - Tires and Brakes dash helpers (prefix tb_)
//
// Tire temps: inner / middle / outer per corner where the sim supplies them
// (LMU, rFactor 2, AMS2, iRacing in the pits). Where it doesn't (ACC, Forza),
// each tire falls back to its single average temp in the middle column.
// iRacing only updates its zone temps when you pit - the dash shows a note.
//
// Colour ranges are in Celsius and converted when SimHub is set to Fahrenheit.
// Tune them here per car class.

var TB_P = 'DataCorePlugin.GameData.NewData.';

var TB_TYRE  = [80, 100, 110];   // cold below / optimal below / warm below / hot above (deg C)
var TB_BRAKE = [300, 700, 850];

var TB_COLD = '#FF4C8DFF';
var TB_OPT  = '#FF2FD3C8';
var TB_WARM = '#FFFFC21A';
var TB_HOT  = '#FFFF453A';
var TB_NONE = '#FF2A313A';
var TB_TEXT = '#FFE8EDF2';
var TB_DIM  = '#FF8A96A3';

function tb_n(v) {
    return (typeof v === 'number' && isFinite(v)) ? v : null;
}

function tb_isF() {
    var u = $prop(TB_P + 'TemperatureUnit');
    return u ? String(u).toLowerCase().indexOf('f') === 0 : false;
}

function tb_lim(c) {
    return tb_isF() ? c * 9 / 5 + 32 : c;
}

function tb_band(v, t) {
    if (v === null) return TB_NONE;
    if (v < tb_lim(t[0])) return TB_COLD;
    if (v < tb_lim(t[1])) return TB_OPT;
    if (v < tb_lim(t[2])) return TB_WARM;
    return TB_HOT;
}

function tb_bandText(v, t) {
    return v === null ? TB_DIM : tb_band(v, t);
}

// ---- tires ----

function tb_avg(c) {
    var v = tb_n($prop(TB_P + 'TyreTemperature' + c));
    return (v === null || v === 0) ? null : v;
}

function tb_zones(c) {
    var i = tb_n($prop(TB_P + 'TyreTemperature' + c + 'Inner'));
    var m = tb_n($prop(TB_P + 'TyreTemperature' + c + 'Middle'));
    var o = tb_n($prop(TB_P + 'TyreTemperature' + c + 'Outer'));
    if (i === null || m === null || o === null) return null;
    if (i === 0 && m === 0 && o === 0) return null;
    return { Inner: i, Middle: m, Outer: o };
}

function tb_hasZones(c) {
    return tb_zones(c) !== null;
}

function tb_zone(c, z) {
    var zs = tb_zones(c);
    if (zs) return zs[z];
    return tb_avg(c);
}

function tb_zoneCol(c, z) {
    return tb_band(tb_zone(c, z), TB_TYRE);
}

function tb_zoneText(c, z) {
    if (!tb_hasZones(c) && z !== 'Middle') return '';
    var v = tb_zone(c, z);
    return v === null ? '--' : Math.round(v).toString();
}

function tb_psi(c) {
    var v = tb_n($prop(TB_P + 'TyrePressure' + c));
    return (v === null || v === 0) ? '--' : v.toFixed(1);
}

function tb_wear(c) {
    var v = tb_n($prop(TB_P + 'TyreWear' + c));
    return v === null ? '--' : Math.round(v) + '%';
}

// ---- brakes ----

function tb_brakeVal(c) {
    var v = tb_n($prop(TB_P + 'BrakeTemperature' + c));
    return (v === null || v === 0) ? null : v;
}

function tb_brakeText(c) {
    var v = tb_brakeVal(c);
    return v === null ? '--' : Math.round(v) + '°';
}

function tb_brakeCol(c) {
    return tb_bandText(tb_brakeVal(c), TB_BRAKE);
}

function tb_axle(a) {
    var l = tb_brakeVal(a + 'Left'), r = tb_brakeVal(a + 'Right');
    if (l === null && r === null) return null;
    if (l === null) return r;
    if (r === null) return l;
    return (l + r) / 2;
}

function tb_axleText(a) {
    var v = tb_axle(a);
    return v === null ? '--' : Math.round(v) + '°';
}

function tb_axleCol(a) {
    return tb_bandText(tb_axle(a), TB_BRAKE);
}

function tb_bias() {
    var v = tb_n($prop(TB_P + 'BrakeBias'));
    return (v === null || v === 0) ? '--' : v.toFixed(1);
}

// ---- misc ----

function tb_compound() {
    var keys = ['TyreCompound', 'TyresCompound', 'TyreDescription'];
    for (var i = 0; i < keys.length; i++) {
        var v = $prop(TB_P + keys[i]);
        if (v !== null && v !== undefined && String(v).length > 0) return String(v).toUpperCase();
    }
    return '';
}

function tb_isIRacing() {
    return $prop('DataCorePlugin.CurrentGame') === 'IRacing';
}
