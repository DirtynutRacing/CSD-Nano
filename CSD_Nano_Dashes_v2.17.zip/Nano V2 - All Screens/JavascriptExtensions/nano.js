/*
 * CSD Nano Dashes - nano.js
 * Copyright (c) 2026 DIRTYNUT. All rights reserved.
 *
 * NOT open source. Free for personal, non-commercial use on your own rig only.
 * You may NOT copy, re-upload, redistribute, sell or charge for this file or
 * the dashboards, publish modified or derived versions, or use them to make a
 * competing dashboard. Do not remove this notice.
 * Full terms: LICENSE.txt in the dashboard folder.
 *
 * Provided "as is", without warranty of any kind.
 */

// Conspit CSD Nano dashes (V2 / V3 / V4) - shared timing helpers
//
// Delta: LMU's own delta (mDeltaBest from the game's telemetry) - the exact number
// the game shows, full precision. Falls back to SimHub's session-best delta for other
// sims. iRacing: its own LapDeltaToSessionBestLap / LapBestLapTime. Like the game, no
// delta until you've completed a full timed lap after the out lap.
// Timing is frozen in the garage / pit lane and on the out lap.

var NANO_P = 'DataCorePlugin.GameData.NewData.';

function nano_secs(t) {
    if (t === null || t === undefined) return 0;
    var s = timespantoseconds(t);
    return (typeof s === 'number' && isFinite(s)) ? s : 0;
}

function nano_num(v) {
    return (typeof v === 'number' && isFinite(v) && v > -600 && v < 600) ? v : null;
}

function nano_inPit() {
    return ($prop(NANO_P + 'IsInPitLane') || $prop(NANO_P + 'IsInPit')) ? true : false;
}

// Out lap = any lap during which you were in the pit lane. Clears on the next lap.
function nano_outLap() {
    var lap = $prop(NANO_P + 'CurrentLap');
    var pit = nano_inPit();
    if (root['nanoLap'] !== lap) {
        root['nanoLap'] = lap;
        root['nanoOut'] = pit;
    } else if (pit) {
        root['nanoOut'] = true;
    }
    return root['nanoOut'] === true;
}

// 0 = timing, 1 = in pits, 2 = out lap
function nano_state() {
    nano_hasTimedLap();                 // keep the lap tracker up to date on every update
    var out = nano_outLap();
    if (nano_inPit()) return 1;
    return out ? 2 : 0;
}

// ------------------------------------------------------------------ delta source
// True once a full lap that started on track (not from the pits) has been completed.
function nano_hasTimedLap() {
    var lap = $prop(NANO_P + 'CurrentLap');
    var key = $prop(NANO_P + 'TrackName') + '|' + $prop(NANO_P + 'CarModel');
    if (root['nanoTKey'] !== key) {
        root['nanoTKey'] = key;
        root['nanoTimed'] = false;
        root['nanoTLap'] = lap;
        root['nanoTClean'] = false;
    }
    if (root['nanoTLap'] !== lap) {
        if (root['nanoTClean'] && typeof lap === 'number' && typeof root['nanoTLap'] === 'number' && lap > root['nanoTLap']) {
            root['nanoTimed'] = true;
        }
        root['nanoTLap'] = lap;
        root['nanoTClean'] = !nano_inPit();
    }
    if (nano_inPit()) root['nanoTClean'] = false;
    if (!(nano_secs($prop('PersistantTrackerPlugin.SessionBest')) > 0)) root['nanoTimed'] = false;   // new session
    return root['nanoTimed'] === true;
}

// The game's own delta, if this sim provides it (LMU does).
var NANO_GAME_DELTA = [
    'DataCorePlugin.GameRawData.PlayerNativeTelemetry.mDeltaBest',
    'GameRawData.PlayerNativeTelemetry.mDeltaBest',
    'DataCorePlugin.GameRawData.CurrentPlayerTelemetry.mDeltaBest',
    'GameRawData.CurrentPlayerTelemetry.mDeltaBest'
];

function nano_gameDelta() {
    for (var i = 0; i < NANO_GAME_DELTA.length; i++) {
        var v = $prop(NANO_GAME_DELTA[i]);
        if (typeof v === 'string') v = parseFloat(v);
        if (typeof v === 'number' && isFinite(v) && v > -600 && v < 600) return v;
    }
    return null;
}

// iRacing's own live delta and session best lap (only present in iRacing).
function nano_raw(name) {
    var v = $prop('DataCorePlugin.GameRawData.Telemetry.' + name);
    if (v === null || v === undefined) v = $prop('GameRawData.Telemetry.' + name);
    return v;
}

function nano_iracing() {
    var d = nano_raw('LapDeltaToSessionBestLap');
    if (typeof d === 'string') d = parseFloat(d);
    if (typeof d !== 'number' || !isFinite(d)) return null;          // not iRacing
    var best = nano_raw('LapBestLapTime');
    if (typeof best === 'string') best = parseFloat(best);
    if (typeof best !== 'number' || !isFinite(best) || best <= 0) best = 0;
    var ok = nano_raw('LapDeltaToSessionBestLap_OK');
    var valid = (ok === undefined || ok === null) ? Math.abs(d) >= 0.001 : (ok === true || ok == 1);
    return { d: (valid && best > 0 && d > -600 && d < 600) ? d : null, ref: best };
}

function nano_source() {
    var ir = nano_iracing();
    if (ir !== null) return ir;
    var timed = nano_hasTimedLap();
    var g = nano_gameDelta();
    if (g !== null) {
        // the game reports 0 while it has no reference lap
        var gref = nano_secs($prop('PersistantTrackerPlugin.SessionBest'));
        return (timed || Math.abs(g) >= 0.001) ? { d: g, ref: gref } : { d: null, ref: gref };
    }
    var ref = nano_secs($prop('PersistantTrackerPlugin.SessionBest'));
    var v = nano_num($prop('PersistantTrackerPlugin.SessionBestLiveDeltaSeconds'));
    if (!timed || !(ref > 0) || v === null) return { d: null, ref: ref };
    return { d: v, ref: ref };
}

// ------------------------------------------------------------------ values for the dash
function nano_delta() {
    return nano_state() === 0 ? nano_source().d : null;
}

function nano_d() {
    var v = nano_delta();
    return v === null ? 0 : v;
}

function nano_ahead() {
    var v = nano_delta();
    return v === null || v <= 0;
}

function nano_col(aheadColour, behindColour) {
    return nano_ahead() ? aheadColour : behindColour;
}

function nano_fmtDelta(v) {
    var dp = 3;
    var txt = Math.abs(v).toFixed(dp);
    if (parseFloat(txt) === 0) return (0).toFixed(dp);
    return (v > 0 ? '+' : '-') + txt;
}

function nano_deltaText() {
    var st = nano_state();
    if (st === 1) return 'PIT';
    if (st === 2) return 'OUT';
    var v = nano_delta();
    return v === null ? '-.---' : nano_fmtDelta(v);
}

function nano_status() {
    var st = nano_state();
    if (st === 1) return 'PIT';
    if (st === 2) return 'OUT LAP';
    var v = nano_delta();
    if (v === null) return 'NO LAP';
    return v <= 0 ? 'AHEAD' : 'BEHIND';
}

function nano_fmtLap(s, zeroText) {
    if (!(s > 0)) return zeroText;
    var ms = Math.round(s * 1000);
    var m = Math.floor(ms / 60000);
    var r = (ms - m * 60000) / 1000;
    var t = r.toFixed(3);
    if (r < 10) t = '0' + t;
    return m + ':' + t;
}

function nano_lapText() {
    var st = nano_state();
    if (st === 1) return 'IN PITS';
    if (st === 2) return 'OUT LAP';
    return nano_fmtLap(nano_secs($prop(NANO_P + 'CurrentLapTime')), '0:00.000');
}

function nano_refSecs() {
    var ir = nano_iracing();
    if (ir !== null) return ir.ref;
    return nano_secs($prop('PersistantTrackerPlugin.SessionBest'));
}

function nano_pbText() {
    if (nano_iracing() === null && !nano_hasTimedLap() && nano_delta() === null) return '-:--.---';    // the out lap doesn't count, like in the game
    return nano_fmtLap(nano_refSecs(), '-:--.---');
}

function nano_predText() {
    if (nano_state() !== 0) return '-:--.---';
    var src = nano_source();
    if (src.d === null || !(src.ref > 0)) return '-:--.---';
    return nano_fmtLap(src.ref + src.d, '-:--.---');
}

// live sector strip on the sectors screen
function nano_liveSector() {
    var s = $prop(NANO_P + 'CurrentSectorIndex');
    return (typeof s === 'number') ? s : 1;
}

// font size that keeps a double-digit delta (e.g. +12.345) on screen
function nano_deltaFont(normal, big) {
    return Math.abs(nano_d()) >= 9.9995 ? big : normal;
}

// ------------------------------------------------------------------ spotter
function nano_flag(name) {
    var v = $prop(name);
    if (v === null || v === undefined) v = $prop(NANO_P + name);
    return v === true || v == 1;
}

// 0 = clear, 1 = car left, 2 = car right, 3 = both sides.
// Holds 0.5 s after a car clears so the screen doesn't flicker. Off when stopped (garage, pit box).
function nano_spot() {
    var now = Date.now();
    var spd = $prop(NANO_P + 'SpeedKmh');
    if (typeof spd === 'number' && spd < 10) {
        root['nanoSpotL'] = 0;
        root['nanoSpotR'] = 0;
        return 0;
    }
    if (nano_flag('SpotterCarLeft')) root['nanoSpotL'] = now;
    if (nano_flag('SpotterCarRight')) root['nanoSpotR'] = now;
    var dl = now - root['nanoSpotL'], dr = now - root['nanoSpotR'];
    var l = root['nanoSpotL'] > 0 && dl >= 0 && dl < 500;
    var r = root['nanoSpotR'] > 0 && dr >= 0 && dr < 500;
    return (l ? 1 : 0) + (r ? 2 : 0);
}

// ------------------------------------------------------------------ inputs screen
var IN_RED = '#FFFF453A', IN_CYAN = '#FF2FD3C8', IN_AMBER = '#FFFFC21A', IN_TEXT = '#FFE8EDF2',
    IN_DIM = '#FF8A96A3', IN_OFF = '#FF2A313A', IN_BADGE_OFF = '#FF1E242C';

function in_num(v) {
    if (typeof v === 'string') v = parseFloat(v);
    return (typeof v === 'number' && isFinite(v)) ? v : null;
}

function in_first(paths) {
    for (var i = 0; i < paths.length; i++) {
        var v = in_num($prop(paths[i]));
        if (v !== null) return v;
    }
    return null;
}

function in_pedal(name) {
    var v = in_first([name, NANO_P + name]);
    if (v === null) return 0;
    return v < 0 ? 0 : (v > 100 ? 100 : v);
}

function in_brake() { return in_pedal('Brake'); }
function in_thr() { return in_pedal('Throttle'); }

// FFB output 0-100 %, or null if the sim doesn't provide it
function in_ffbRaw() {
    var v = in_first(['DataCorePlugin.GameRawData.Telemetry.SteeringWheelPctTorque',      // iRacing
                      'GameRawData.Telemetry.SteeringWheelPctTorque']);
    if (v !== null) return Math.min(100, Math.abs(v) <= 1.5 ? Math.abs(v) * 100 : Math.abs(v));
    v = in_first(['DataCorePlugin.GameRawData.ForceFeedback.mForceValue',                   // rF2 / LMU
                  'GameRawData.ForceFeedback.mForceValue',
                  'GameRawData.PlayerNativeTelemetry.mFFBForce']);
    if (v !== null) return Math.min(100, Math.abs(v) <= 1.5 ? Math.abs(v) * 100 : Math.abs(v));
    return null;
}

// wheel rotation (rad/s) for wheel i (0 FL, 1 FR, 2 RL, 3 RR), or null
function in_wheelRot(i) {
    var bases = ['GameRawData.CurrentPlayerTelemetry', 'DataCorePlugin.GameRawData.CurrentPlayerTelemetry',
                 'GameRawData.PlayerNativeTelemetry'];
    for (var b = 0; b < bases.length; b++) {
        var v = in_first([bases[b] + '.mWheels[' + i + '].mRotation',
                          bases[b] + '.mWheels0' + (i + 1) + '.mRotation',
                          bases[b] + '.mWheel[' + i + '].mRotation',
                          bases[b] + '.mWheel0' + (i + 1) + '.mRotation']);
        if (v !== null) return v;
    }
    return null;
}

// Runs once per update: braking events, FFB clipping per lap, wheel lock latches.
function in_tick() {
    var now = Date.now();
    if (root['inT'] === now) return;
    var prev = root['inT'];
    root['inT'] = now;
    var dt = (typeof prev === 'number' && now > prev && now - prev < 250) ? now - prev : 0;

    // braking event: starts above 5 %, ends below 2 %
    var b = in_brake();
    var ev = root['inEv'];
    if (!ev) {
        if (b > 5) root['inEv'] = { start: now, peak: b, peakT: now };
    } else {
        if (b > ev.peak + 0.5) { ev.peak = b; ev.peakT = now; }
        if (b < 2) {
            if (ev.peak >= 20 && now - ev.start > 150) {
                root['inPrevTTP'] = root['inLastTTP'];
                root['inLastTTP'] = (ev.peakT - ev.start) / 1000;
                root['inLastPeak'] = ev.peak;
            }
            root['inEv'] = null;
        }
    }

    // FFB clipping, % of the current lap's driving time
    var lap = $prop(NANO_P + 'CurrentLap');
    if (root['inLap'] !== lap) { root['inLap'] = lap; root['inDrive'] = 0; root['inClip'] = 0; }
    var f = in_ffbRaw();
    var spd = in_num($prop(NANO_P + 'SpeedKmh'));
    if (f !== null && dt > 0 && spd !== null && spd > 10) {
        root['inDrive'] += dt;
        if (f >= 99) root['inClip'] += dt;
    }

    // wheel lock: wheel surface speed under 60 % of car speed while braking
    var v = (spd || 0) / 3.6, have = false;
    for (var i = 0; i < 4; i++) {
        var rot = in_wheelRot(i);
        if (rot === null) continue;
        have = true;
        if (v > 8 && b > 5 && Math.abs(rot) * 0.33 < 0.6 * v) root['inLock' + i] = now;
    }
    root['inLockData'] = have;
}

function in_peakText() {
    in_tick();
    var ev = root['inEv'];
    var p = ev ? ev.peak : root['inLastPeak'];
    return (typeof p === 'number') ? Math.round(p) + '%' : '--';
}

function in_ttpText() {
    in_tick();
    var t = root['inLastTTP'];
    return (typeof t === 'number') ? t.toFixed(2) : '-.--';
}

function in_ttpDelta() {
    in_tick();
    var a = root['inLastTTP'], b = root['inPrevTTP'];
    if (typeof a !== 'number' || typeof b !== 'number') return '';
    var d = a - b;
    var txt = Math.abs(d).toFixed(2);
    if (parseFloat(txt) === 0) return '0.00';
    return (d > 0 ? '+' : '-') + txt;
}

function in_ttpDeltaCol() {
    var t = in_ttpDelta();
    return t.charAt(0) === '-' ? IN_CYAN : (t.charAt(0) === '+' ? IN_RED : IN_DIM);
}

function in_ffbText() {
    var f = in_ffbRaw();
    return f === null ? '--' : Math.round(f) + '%';
}

function in_ffbWidth(full) {
    var f = in_ffbRaw();
    return f === null ? 0 : Math.max(0, Math.min(full, full * f / 100));
}

function in_ffbCol() {
    var f = in_ffbRaw();
    return (f !== null && f >= 99) ? IN_RED : IN_CYAN;
}

function in_clipText() {
    in_tick();
    if (in_ffbRaw() === null) return '--';
    var d = root['inDrive'] || 0;
    return (d > 0 ? (100 * (root['inClip'] || 0) / d) : 0).toFixed(1) + '% LAP';
}

// latched 0.5 s so a short lock is still readable
function in_locked(i) {
    in_tick();
    var t = root['inLock' + i];
    return typeof t === 'number' && Date.now() - t < 500;
}

function in_lockCol(i) {
    return in_locked(i) ? IN_RED : IN_OFF;
}

function in_lockText() {
    in_tick();
    if (!root['inLockData']) return '';
    var names = ['FL', 'FR', 'RL', 'RR'], out = [];
    for (var i = 0; i < 4; i++) if (in_locked(i)) out.push(names[i]);
    if (out.length === 4) return 'ALL LOCK';
    return out.length ? out.join('+') + ' LOCK' : '';
}

// ABS / TC lights, held 0.3 s so flicker is still visible
function in_aid(name) {
    var now = Date.now();
    if (nano_flag(name)) root['inAid' + name] = now;
    var t = root['inAid' + name];
    return typeof t === 'number' && now - t >= 0 && now - t < 300;
}

function in_aidBg(name) { return in_aid(name) ? IN_AMBER : IN_BADGE_OFF; }
function in_aidText(name) { return in_aid(name) ? '#FF000000' : IN_DIM; }

// ------------------------------------------------------------------ sectors (any number)
// iRacing: sector layout from SplitTimeInfo, sector times measured here from lap position.
// Other sims: SimHub's 3 sectors. The 3 panels show a rolling window: the two sectors
// before the one you're in, plus the live one.
var MS_SPLITS = 'GameRawData.SessionData.SplitTimeInfo.Sectors';
var MS_COL = ['#FF4FC3F7', '#FF4FC3F7', '#FF9B4DFF', '#FF2EE66B', '#FFFFD23F', '#FF2A2A2A'];

function ms_n(v) {
    if (typeof v === 'string') v = parseFloat(v);
    return (typeof v === 'number' && isFinite(v)) ? v : null;
}

function ms_ir(name) {
    var v = ms_n($prop('DataCorePlugin.GameRawData.Telemetry.' + name));
    return v !== null ? v : ms_n($prop('GameRawData.Telemetry.' + name));
}

// sector start positions (0-1) from iRacing, or null for other sims
function ms_starts() {
    var out = [];
    for (var i = 1; i <= 30; i++) {
        var k = (i < 10 ? '0' : '') + i;
        var v = ms_n($prop('DataCorePlugin.' + MS_SPLITS + k + '.SectorStartPct'));
        if (v === null) v = ms_n($prop(MS_SPLITS + k + '.SectorStartPct'));
        if (v === null) break;
        out.push(v);
    }
    return out.length >= 2 ? out : null;
}

function ms_sum(a, upto) {
    var s = 0;
    for (var i = 0; i <= upto; i++) {
        if (!(a[i] > 0)) return 0;
        s += a[i];
    }
    return s;
}

// iRacing: every time a sector line is crossed (start/finish included) its exact moment is
// recorded on iRacing's SessionTime clock, interpolated between updates. A sector's time is
// the gap between its two lines, and the live timer counts from the line you last crossed.
// Nothing depends on the lap counter or on having seen a whole lap.
function ms_tickIr(starts) {
    var p = ms_ir('LapDistPct');
    if (p === null) p = ms_n($prop(NANO_P + 'TrackPositionPercent'));
    if (p === null || p < 0) return;
    var st = ms_ir('SessionTime');
    if (st === null) st = Date.now() / 1000;
    var sig = p + '|' + st;
    if (root['msSig'] === sig) return;
    root['msSig'] = sig;

    var N = starts.length;
    var dbg = root['msDbg'] || (root['msDbg'] = { fw: 0, wrap: 0, jump: 0, back: 0, init: 0, upd: 0, last: '' });
    dbg.upd++;
    var key = $prop(NANO_P + 'TrackName') + '|' + $prop(NANO_P + 'CarModel') + '|' + N;
    if (root['msKey'] !== key) {
        root['msKey'] = key;
        root['msPrev'] = null; root['msEnter'] = null; root['msThis'] = []; root['msLast'] = [];
        root['msLapClean'] = true; root['msBestLap'] = null; root['msBestT'] = 0; root['msSBest'] = [];
    }
    var c = 0;
    for (var i = 0; i < N; i++) if (p >= starts[i]) c = i;
    var clean = nano_state() === 0;

    var prev = root['msPrev'];
    var ent = root['msEnter'];
    if (!prev || !ent || st < prev.st) {             // no history yet, or the clock went backwards (replay/reset)
        if (prev && st < prev.st) { dbg.back++; dbg.last = 'BACK ' + prev.st.toFixed(2) + '>' + st.toFixed(2); } else dbg.init++;
        if (!ent || ent.c !== c) root['msEnter'] = { c: c, st: st, exact: false, clean: clean };
    } else if (c !== prev.c) {
        var forward = p > prev.p && p - prev.p < 0.2;
        var wrap = prev.p > 0.85 && p < 0.15;
        if (forward || wrap) {
            if (wrap) dbg.wrap++; else dbg.fw++;
            // walk through every line passed since the last update
            var span = wrap ? (1 - prev.p) + p : p - prev.p;
            var k = prev.c;
            while (k !== c) {
                var nk = (k + 1) % N;
                var linePct = nk === 0 ? 1 : starts[nk];
                var f = (linePct - prev.p) / (span || 1);
                var tCross = prev.st + (st - prev.st) * Math.max(0, Math.min(1, f));
                ms_sectorDone(k, ent, tCross, N);
                if (nk === 0) ms_lapDone(N);
                ent = { c: nk, st: tCross, exact: true, clean: clean };
                k = nk;
            }
            root['msEnter'] = ent;
        } else {
            // jumped (reset, tow, replay): restart timing from the next line
            dbg.jump++;
            dbg.last = 'JUMP S' + (prev.c + 1) + '>S' + (c + 1) + ' p ' + prev.p.toFixed(4) + '>' + p.toFixed(4);
            root['msEnter'] = { c: c, st: st, exact: false, clean: false };
            root['msLapClean'] = false;
        }
    }
    if (!clean) {
        root['msEnter'].clean = false;
        root['msLapClean'] = false;
    }
    root['msPrev'] = { p: p, st: st, c: c };
    root['msC'] = c;
}

function ms_sectorDone(k, ent, tCross, N) {
    if (!ent || ent.c !== k || !ent.exact) return;
    var d = tCross - ent.st;
    if (!(d > 0)) return;
    root['msThis'][k] = d;
    if (ent.clean) {
        var sb = root['msSBest'];
        if (!(sb[k] > 0) || d < sb[k]) sb[k] = d;
    }
}

function ms_lapDone(N) {
    var sec = root['msThis'], all = true, lapTime = 0;
    for (var j = 0; j < N; j++) {
        if (!(sec[j] > 0)) all = false; else lapTime += sec[j];
    }
    root['msLast'] = sec;
    root['msThis'] = [];
    var clean = root['msLapClean'];
    root['msLapClean'] = true;
    if (!all || !clean) return;
    var irBest = ms_ir('LapBestLapTime');
    var counts = !(irBest > 0) || Math.abs(irBest - lapTime) < 0.05;     // iRacing excludes invalid laps
    if (counts && (!(root['msBestT'] > 0) || lapTime < root['msBestT'])) {
        root['msBestT'] = lapTime;
        root['msBestLap'] = sec.slice(0);
    }
}

// ---- Lovely plugin (TeamLINQ): it times every car's sectors itself; used in iRacing when installed
var LV = 'LovelyPlugin.TeamLINQ.';

function lv_json(name) {
    var str = $prop(LV + 'Opponents.' + name);
    if (typeof str !== 'string' || str.length < 2) return null;
    if (root['lvS_' + name] === str) return root['lvP_' + name];
    var parsed = null;
    try { parsed = JSON.parse(str); } catch (e) { parsed = null; }
    root['lvS_' + name] = str;
    root['lvP_' + name] = parsed;
    return parsed;
}

// my car's entry: the lists are ordered by leaderboard position
function lv_mine(name, pos) {
    var d = lv_json(name);
    if (!d || !d[pos - 1]) return null;
    return d[pos - 1].Data || null;
}

// lap time at the end of sector k (1-based), in seconds
function lv_cum(D, k) {
    if (k === 0) return 0;
    var e = D ? D[k] : null;
    var v = e ? ms_n(e.SectorTimeMS) : null;
    return (v !== null && v > 0) ? v / 1000 : null;
}

function lv_durations(D, N) {
    var out = [];
    for (var j = 0; j < N; j++) {
        var a = lv_cum(D, j), b = lv_cum(D, j + 1);
        out.push((a !== null && b !== null && b > a) ? b - a : 0);
    }
    return out;
}

function ms_lovely() {
    var N = ms_n($prop(LV + 'Session.SectorsCount'));
    var pos = ms_n($prop(LV + 'Session.Position'));
    var cs = ms_n($prop(LV + 'Session.CurrentSector'));
    if (!(N >= 2) || !(pos >= 1) || cs === null) return null;
    var curD = lv_mine('SectorsCurrentLap', pos);
    if (!curD) return null;
    var c = Math.max(0, Math.min(N - 1, Math.round(cs) - 1));
    var cur = lv_durations(curD, N);
    for (var j = c; j < N; j++) cur[j] = 0;                 // only sectors already finished this lap
    var bs = lv_mine('SectorsBestSplits', pos), sbest = [];
    for (var k = 0; k < N; k++) {
        var e = bs ? bs[k + 1] : null, v = e ? ms_n(e.SplitTimeMS) : null;
        sbest.push(v !== null && v > 0 ? v / 1000 : 0);
    }
    return { N: N, c: c, ir: true, lv: true, curD: curD, cur: cur,
             last: lv_durations(lv_mine('SectorsLastLap', pos), N),
             best: lv_durations(lv_mine('SectorsBestLap', pos), N), sbest: sbest };
}

// common model: N, live sector c, this lap / last lap / best-lap / session-best sector times
function ms_model() {
    var key = Date.now();
    if (root['msMT'] === key && root['msM']) return root['msM'];
    var m;
    var starts = ms_starts();
    var lv = starts ? ms_lovely() : null;
    if (lv) {
        m = lv;
    } else if (starts) {
        ms_tickIr(starts);
        var N = starts.length, c = root['msC'] || 0;
        m = { N: N, c: c, ir: true, cur: root['msThis'] || [], last: root['msLast'] || [], best: root['msBestLap'] || [],
              sbest: root['msSBest'] || [] };
    } else {
        var idx = $prop(NANO_P + 'CurrentSectorIndex');
        idx = (typeof idx === 'number' && idx >= 1) ? idx : 1;
        var g = function (n, kind) { return nano_secs($prop(NANO_P + 'Sector' + n + kind)); };
        m = { N: 3, c: Math.min(2, idx - 1), ir: false,
              cur: [g(1, 'Time'), g(2, 'Time'), g(3, 'Time')],
              last: [g(1, 'LastLapTime'), g(2, 'LastLapTime'), g(3, 'LastLapTime')],
              best: [g(1, 'BestLapTime'), g(2, 'BestLapTime'), g(3, 'BestLapTime')],
              sbest: [g(1, 'BestTime'), g(2, 'BestTime'), g(3, 'BestTime')] };
    }
    root['msMT'] = key;
    root['msM'] = m;
    return m;
}

// which sector a panel (1-3) shows
function ms_slot(n) {
    var m = ms_model();
    var w0 = Math.max(0, Math.min(m.c - 2, m.N - 3));
    return w0 + n - 1;
}

function ms_done(m, s) {
    return s < m.c ? (m.cur[s] || 0) : (m.last[s] || 0);
}

function nano_sLive(n) {
    return ms_slot(n) === ms_model().c;
}

function nano_sLabel(n) {
    var s = ms_slot(n);
    return s < ms_model().N ? 'S' + (s + 1) : '';
}

// 0 live ahead, 1 live behind, 2 session best, 3 faster than best lap, 4 slower, 5 no data
function ms_state(m, s) {
    if (s >= m.N) return 5;
    if (s === m.c) return nano_ahead() ? 0 : 1;
    var d = ms_done(m, s);
    if (!(d > 0)) return 5;
    if (m.sbest[s] > 0 && d <= m.sbest[s] + 0.0005) return 2;
    if (m.best[s] > 0 && d <= m.best[s] + 0.0005) return 3;          // equal to your best lap counts as green
    return 4;
}

function nano_sState(n) {
    var m = ms_model();
    return ms_state(m, ms_slot(n));
}

// sector duration: 18.412 (or 1:02.345 for long sectors)
function ms_fmtSec(d, dp) {
    if (!(d > 0)) return dp === 1 ? '--.-' : '--.---';
    if (d < 60) return d.toFixed(dp);
    var mm = Math.floor(d / 60), r = d - mm * 60;
    return mm + ':' + (r < 10 ? '0' : '') + r.toFixed(dp);
}

function nano_sTime(n) {
    var m = ms_model(), s = ms_slot(n);
    if (s >= m.N) return '';
    if (m.ir) {
        // iRacing: each sector's own time; the live panel counts up the current sector
        if (s === m.c) return nano_state() === 1 ? '--.-' : nano_curRun();
        return ms_fmtSec(ms_done(m, s), 3);
    }
    if (s === m.c) {
        if (nano_state() === 1) return '-:--.-';
        var t = m.ir ? ms_ir('LapCurrentLapTime') : null;
        if (t === null) t = nano_secs($prop(NANO_P + 'CurrentLapTime'));
        var ms = Math.round(t * 10);
        var mm = Math.floor(ms / 600), r = (ms - mm * 600) / 10;
        return mm + ':' + (r < 10 ? '0' : '') + r.toFixed(1);
    }
    var split = s < m.c ? ms_sum(m.cur, s) : ms_sum(m.last, s);
    return nano_fmtLap(split, '-:--.---');
}

function nano_sDelta(n) {
    var m = ms_model(), s = ms_slot(n);
    if (s >= m.N) return '';
    if (s === m.c) return nano_deltaText();
    var d = ms_done(m, s);
    if (!(d > 0) || !(m.best[s] > 0)) return '-.---';
    return nano_fmtDelta(d - m.best[s]);
}

// V4 left side: current sector and its running time
function nano_curLabel() {
    return 'S' + (ms_model().c + 1);
}

function nano_curRun() {
    var m = ms_model();
    if (nano_state() === 1) return '0.0';
    if (m.lv) {
        // Lovely: current lap time minus the lap time when this sector started
        var lapNow = nano_secs($prop(LV + 'LapTime.Current'));
        var start = lv_cum(m.curD, m.c);
        if (lapNow > 0 && start !== null && lapNow >= start) return ms_fmtSec(Math.max(0.0001, lapNow - start), 1);
        return '--.-';
    }
    if (m.ir) {
        var ent = root['msEnter'], prev = root['msPrev'];
        if (ent && prev && ent.exact && ent.c === m.c) return ms_fmtSec(Math.max(0.0001, prev.st - ent.st), 1);
        if (m.c === 0) {                       // in S1 the sector time is simply the lap timer
            var lt = ms_ir('LapCurrentLapTime');
            if (lt !== null && lt > 0) return ms_fmtSec(lt, 1);
        }
        return '--.-';
    }
    var t = m.ir ? ms_ir('LapCurrentLapTime') : null;
    if (t === null) t = nano_secs($prop(NANO_P + 'CurrentLapTime'));
    var done = m.c > 0 ? ms_sum(m.cur, m.c - 1) : 0;
    if (m.c > 0 && done === 0) return '--.-';
    return Math.max(0, t - done).toFixed(1);
}

// bottom strip with every sector (only when there are more than 3)
function nano_stripOn(i) {
    var m = ms_model();
    return m.N > 3 && i < m.N;
}

function nano_stripCol(i) {
    var m = ms_model();
    return MS_COL[ms_state(m, i)];
}

function nano_stripLeft(i, x0, w, gap) {
    var N = Math.max(1, ms_model().N);
    return x0 + i * ((w - gap * (N - 1)) / N + gap);
}

function nano_stripWidth(w, gap) {
    var N = Math.max(1, ms_model().N);
    return (w - gap * (N - 1)) / N;
}


// ------------------------------------------------------------------ debug screen
function dbg_v(name) {
    var v = $prop(name);
    if (v === null || v === undefined) return 'null';
    if (typeof v === 'number') return (Math.round(v * 10000) / 10000).toString();
    return String(v).substring(0, 14);
}

function nano_dbg(line) {
    var m = ms_model();
    var T = 'DataCorePlugin.GameRawData.Telemetry.';
    var ent = root['msEnter'], prev = root['msPrev'], d = root['msDbg'] || {};
    var arr = function (a) { var o = []; for (var i = 0; i < m.N; i++) o.push(a && a[i] > 0 ? a[i].toFixed(2) : '-'); return o.join(' '); };
    switch (line) {
        case 0: return 'MODE ' + (m.lv ? 'iRacing via Lovely' : (m.ir ? 'iRacing own timing' : 'SimHub 3')) + '   N ' + m.N + '   c S' + (m.c + 1) + '   state ' + nano_state();
        case 1: return 'LapDistPct ' + dbg_v(T + 'LapDistPct') + '   TrackPos% ' + dbg_v(NANO_P + 'TrackPositionPercent');
        case 2: return 'SessionTime ' + dbg_v(T + 'SessionTime') + '   LapCurTime ' + dbg_v(T + 'LapCurrentLapTime');
        case 3: return 'prev p ' + (prev ? prev.p.toFixed(4) : '-') + '  st ' + (prev ? prev.st.toFixed(2) : '-') +
                       '   enter S' + (ent ? ent.c + 1 : '-') + (ent && ent.exact ? ' EXACT' : ' notexact') +
                       (ent && prev ? ' ' + (prev.st - ent.st).toFixed(1) + 's' : '');
        case 4: return 'upd ' + (d.upd || 0) + '  fw ' + (d.fw || 0) + '  wrap ' + (d.wrap || 0) + '  jump ' + (d.jump || 0) +
                       '  back ' + (d.back || 0) + '  init ' + (d.init || 0);
        case 5: return 'last: ' + (d.last || '-');
        case 6: return 'this ' + arr(root['msThis']);
        case 7: return 'last ' + arr(root['msLast']);
    }
    return '';
}


// ------------------------------------------------------------------ flag frame
// Thin border (4 solid bars) in the flag's colour. Most important flag wins.
// Coloured flags flash fast (0.15 s on / 0.15 s off); black flashes grey so it shows
// on a black screen; chequered shows two white/black chequer patterns that swap;
// green only shows for 4 s.
var FL_FLASH_MS = 150;
var FL_LIST = [['Checkered', 'chk'], ['Black', '#FF9A9A9A'], ['Red', '#FFFF1E1E'], ['Yellow', '#FFFFD200'],
               ['Blue', '#FF1E7BFF'], ['Orange', '#FFFF8C00'], ['White', '#FFFFFFFF'], ['Green', '#FF22DD44']];

function nano_flagNow() {
    var now = Date.now();
    if (root['flT'] === now) return root['flC'];
    root['flT'] = now;
    var cur = null;
    for (var i = 0; i < FL_LIST.length; i++) {
        if (nano_flag('Flag_' + FL_LIST[i][0])) { cur = FL_LIST[i]; break; }
    }
    if (cur && cur[0] === 'Green') {
        if (typeof root['flGreen'] !== 'number') root['flGreen'] = now;
        if (now - root['flGreen'] > 4000) cur = null;
    } else if (!nano_flag('Flag_Green')) {
        root['flGreen'] = null;
    }
    root['flC'] = cur;
    return cur;
}

function nano_flagVis(i) {
    var f = nano_flagNow();
    if (!f) return false;
    if (f[1] === 'chk') return true;
    return Math.floor(Date.now() / FL_FLASH_MS) % 2 === 0;
}

// chequered: white squares, two patterns swapping every 0.25 s
function nano_chkOn(k) {
    var f = nano_flagNow();
    return !!f && f[1] === 'chk' && Math.floor(Date.now() / 250) % 2 === k;
}

function nano_flagCol(i) {
    var f = nano_flagNow();
    if (!f) return '#00000000';
    if (f[1] === 'chk') return '#FF000000';
    return f[1];
}

// ------------------------------------------------------------------ fuel
// Fuel left, laps of fuel, use per lap, fuel to add to finish, low-fuel warning.
// Uses SimHub's fuel calculations; falls back to measuring fuel use per lap itself.
var FU_LOW_LAPS = 2.0;      // warning when this many laps of fuel or less are left (and you can't finish)
var FU_BLINK_MS = 400;

function fu_get(names) {
    for (var i = 0; i < names.length; i++) {
        var v = $prop(names[i]);
        if (v !== null && v !== undefined && v !== '') return v;
    }
    return null;
}

function fu_n(v) {
    if (typeof v === 'string') v = parseFloat(v);
    return (typeof v === 'number' && isFinite(v)) ? v : null;
}

function fu_g(name) {
    return fu_n(fu_get(['DataCorePlugin.GameData.' + name, NANO_P + name, name]));
}

function fu_c(name) {
    return fu_n(fu_get(['DataCorePlugin.Computed.' + name]));
}

// own per-lap measurement (fallback), updated once per frame
function fu_tick() {
    var now = Date.now();
    if (root['fuT'] === now) return;
    root['fuT'] = now;
    var fuel = fu_g('Fuel'), pos = fu_g('TrackPositionPercent');
    if (fuel === null || pos === null) return;
    if (root['fuUse'] === undefined) { root['fuUse'] = []; root['fuLast'] = null; }
    if (typeof root['fuStart'] !== 'number') { root['fuStart'] = fuel; root['fuOk'] = false; }
    if (nano_inPit() || fuel > root['fuPrev'] + 0.3) root['fuOk'] = false;      // pit stop or refuel: lap doesn't count
    var prevPos = root['fuPos'];
    if (typeof prevPos === 'number' && prevPos > 0.9 && pos < 0.1) {             // crossed the line
        var used = root['fuStart'] - fuel;
        if (root['fuOk'] && used > 0.01) {
            root['fuLast'] = used;
            root['fuUse'].push(used);
            if (root['fuUse'].length > 5) root['fuUse'].shift();
        }
        root['fuStart'] = fuel;
        root['fuOk'] = !nano_inPit();
    }
    root['fuPos'] = pos;
    root['fuPrev'] = fuel;
}

function fu_model() {
    var now = Date.now();
    if (root['fuMT'] === now) return root['fuM'];
    root['fuMT'] = now;
    fu_tick();
    var m = {};
    m.fuel = fu_g('Fuel');
    var pct = fu_g('FuelPercent'), max = fu_g('MaxFuel');
    if (pct !== null && pct > 0) m.pct = Math.min(1, pct / 100);
    else m.pct = (m.fuel !== null && max > 0) ? Math.min(1, m.fuel / max) : 0;
    var use = root['fuUse'] || [];
    var own = use.length ? use.reduce(function (a, b) { return a + b; }, 0) / use.length : null;
    m.per = fu_c('Fuel_LitersPerLap');
    if (!(m.per > 0)) m.per = own;
    m.last = fu_c('Fuel_LastLapConsumption');
    if (!(m.last > 0)) m.last = root['fuLast'] || null;
    m.laps = (m.fuel !== null && m.per > 0) ? m.fuel / m.per : null;
    // distance left in the race, in laps
    var pos = fu_g('TrackPositionPercent') || 0;
    var total = fu_g('TotalLaps'), done = fu_g('CompletedLaps'), cur = fu_g('CurrentLap');
    m.dist = null;
    if (total > 0) {
        if (done === null && cur !== null) done = Math.max(0, cur - 1);
        if (done !== null) m.dist = Math.max(0, total - done - pos);
    } else {
        var left = nano_secs(fu_get(['DataCorePlugin.GameData.SessionTimeLeft', NANO_P + 'SessionTimeLeft']));
        var ref = nano_refSecs() || nano_secs(fu_get(['DataCorePlugin.GameData.LastLapTime', NANO_P + 'LastLapTime']));
        if (left > 0 && left < 36000 && ref > 0) m.dist = Math.max(0, Math.ceil(pos + left / ref) - pos);
    }
    m.need = (m.dist !== null && m.per > 0 && m.fuel !== null) ? m.dist * m.per - m.fuel : null;
    m.low = m.laps !== null && m.laps <= FU_LOW_LAPS && !nano_inPit() && (m.need === null || m.need > 0);
    root['fuM'] = m;
    return m;
}

function fu_f1(v) { return v === null || v === undefined ? '--' : (v >= 100 ? v.toFixed(0) : v.toFixed(1)); }
function fu_f2(v) { return v === null || v === undefined ? '--' : v.toFixed(2); }

function fu_low() { return fu_model().low; }
function fu_normal() { return !fu_model().low; }
function fu_blink() { return fu_model().low && Math.floor(Date.now() / FU_BLINK_MS) % 2 === 0; }
function fu_lapsText() { return fu_f1(fu_model().laps); }
function fu_fuelText() { return fu_f1(fu_model().fuel) + ' L'; }
function fu_perText() { var p = fu_model().per; return p > 0 ? fu_f2(p) + ' L' : '--'; }
function fu_lastText() { var p = fu_model().last; return p > 0 ? fu_f2(p) + ' L' : '--'; }
function fu_needText() {
    var n = fu_model().need;
    if (n === null) return '--';
    return n <= 0 ? 'ENOUGH' : '+' + n.toFixed(1) + ' L';
}
function fu_addText() { var t = fu_needText(); return t === '--' || t === 'ENOUGH' ? t : 'ADD ' + t; }
function fu_needCol(okCol, needCol) { var n = fu_model().need; return (n !== null && n > 0) ? needCol : okCol; }
function fu_togoText(suffix) {
    var d = fu_model().dist;
    if (d === null) return '';
    var n = Math.ceil(d - 0.001);
    suffix = suffix || '';
    if (n === 1) suffix = suffix.replace('LAPS', 'LAP');
    return n + suffix;
}
function fu_pctText() { return Math.round(fu_model().pct * 100) + '% TANK'; }
function fu_seg(i, n) { return fu_model().pct >= (i + 0.5) / n; }
function fu_lowCol(normal, low) { return fu_model().low ? low : normal; }

// ------------------------------------------------------------------ lap history
// Last 10 laps vs your session best. Invalid laps show INV, laps that touched the
// pit lane (out / in laps) show PIT; both are left out of the average and consistency.
var LH_N = 10;
var LH_GOOD = 0.35;         // within this of your best = green, slower = yellow
var LH_BASE = 214, LH_TOP = 44, LH_MIN = 40;

function lh_last() { return nano_secs($prop(NANO_P + 'LastLapTime')); }

function lh_invalidNow() {
    if ($prop(NANO_P + 'LapInvalidated')) return true;
    return $prop(NANO_P + 'IsLapValid') === false;
}

function lh_tick() {
    var now = Date.now();
    if (root['lhT'] === now) return;
    root['lhT'] = now;
    var lap = $prop(NANO_P + 'CurrentLap');
    var key = $prop(NANO_P + 'TrackName') + '|' + $prop(NANO_P + 'CarModel');
    if (root['lhKey'] !== key || (typeof lap === 'number' && typeof root['lhLap'] === 'number' && lap < root['lhLap'])) {
        root['lhKey'] = key;
        root['lhHist'] = [];
        root['lhPend'] = null;
        root['lhLap'] = lap;
        root['lhInv'] = false;
        root['lhPit'] = nano_inPit();
        root['lhLast0'] = lh_last();
    }
    if (lh_invalidNow()) root['lhInv'] = true;
    if (nano_inPit()) root['lhPit'] = true;
    if (typeof lap === 'number' && typeof root['lhLap'] === 'number' && lap > root['lhLap']) {
        // crossed the line: remember how this lap went, wait for the game to post its time
        root['lhPend'] = { n: root['lhLap'], inv: root['lhInv'], pit: root['lhPit'], t0: now,
                           last0: typeof root['lhLast0'] === 'number' ? root['lhLast0'] : lh_last() };
        root['lhInv'] = lh_invalidNow();
        root['lhPit'] = nano_inPit();
    }
    root['lhLap'] = lap;
    var p = root['lhPend'];
    if (p) {
        var last = lh_last();
        if ((last > 0 && Math.abs(last - p.last0) > 0.0005) || (now - p.t0 > 6000 && last > 0) || now - p.t0 > 10000) {
            if (last > 0) {
                root['lhLast0'] = last;
                root['lhHist'].push({ n: p.n, t: last, inv: p.inv, pit: p.pit });
                if (root['lhHist'].length > LH_N) root['lhHist'].shift();
            }
            root['lhPend'] = null;
        }
    }
}

function lh_clean() {
    lh_tick();
    return (root['lhHist'] || []).filter(function (l) { return !l.inv && !l.pit; });
}

function lh_best() {
    var ref = nano_refSecs();
    var c = lh_clean();
    var m = 0;
    for (var i = 0; i < c.length; i++) if (!(m > 0) || c[i].t < m) m = c[i].t;
    if (ref > 0 && (!(m > 0) || ref < m)) return ref;
    return m;
}

function lh_item(i) { lh_tick(); var h = root['lhHist'] || []; return i < h.length ? h[i] : null; }

function lh_d(l) { var b = lh_best(); return b > 0 ? l.t - b : 0; }

function lh_vis(i) { return lh_item(i) !== null; }

function lh_h(i) {
    var l = lh_item(i), full = LH_BASE - LH_TOP;
    if (!l) return 0;
    if (l.inv || l.pit) return full;
    var d = Math.max(0, lh_d(l));
    return LH_MIN + Math.min(d, 1) * (full - LH_MIN);
}

function lh_top(i) { return LH_BASE - lh_h(i); }

function lh_col(i) {
    var l = lh_item(i);
    if (!l) return '#00000000';
    if (l.inv) return '#FFFF2D55';
    if (l.pit) return '#FF2A3A48';
    var d = lh_d(l);
    if (d < 0.0005) return '#FF9B4DFF';
    return d <= LH_GOOD ? '#FF2EE66B' : '#FFFFD23F';
}

function lh_lab(i) {
    var l = lh_item(i);
    if (!l) return '';
    if (l.inv) return 'INV';
    if (l.pit) return 'PIT';
    var d = lh_d(l);
    return d < 0.0005 ? 'BEST' : (d >= 10 ? '+' + d.toFixed(1) : '+' + d.toFixed(2));
}

function lh_inside(i) { return lh_h(i) > LH_BASE - LH_TOP - 20; }
function lh_labTop(i) { return lh_inside(i) ? lh_top(i) + 2 : lh_top(i) - 24; }
function lh_labCol(i) { return lh_inside(i) ? '#FF05070C' : '#FFFFFFFF'; }
function lh_num(i) { var l = lh_item(i); return l ? String(l.n) : ''; }

function lh_avg() {
    var c = lh_clean();
    if (!c.length) return null;
    return c.reduce(function (a, l) { return a + l.t; }, 0) / c.length;
}

function lh_consText() {
    var c = lh_clean();
    if (c.length < 2) return '--';
    var a = lh_avg();
    var v = c.reduce(function (s, l) { return s + (l.t - a) * (l.t - a); }, 0) / c.length;
    return '±' + Math.sqrt(v).toFixed(3);
}

function lh_avgText() { return nano_fmtLap(lh_avg(), '-:--.---'); }
function lh_bestText() { return nano_fmtLap(lh_best(), '-:--.---'); }

// ------------------------------------------------------------------ all-screens dashes
// SimHub only evaluates the screen being shown, so every screen of an "All Screens" dash has an
// invisible item bound to this: it keeps lap history, fuel use, sector timing and the
// pit / timed-lap state counting while you're looking at another screen.
function nano_tickAll() {
    nano_state();
    nano_hasTimedLap();
    ms_model();
    fu_model();
    lh_tick();
    idle_track();
    return false;
}

// ------------------------------------------------------------------ style colours
// V2 / V3 versions of the V4-only screens reuse the V4 logic; their colour bindings are
// wrapped in nano_map so the live colours come out in that style's palette.
function nano_map(c, m) {
    if (typeof c !== 'string') return c;
    var k = c.toUpperCase();
    return m.hasOwnProperty(k) ? m[k] : c;
}

// ------------------------------------------------------------------ idle screen
// Shown by SimHub when no game is running: your name, clock and date, and a card with your
// last session (track, car, sim, best lap, laps, consistency). Settings are in idle_settings.js.
function idle_cfgName() { return (typeof IDLE_NAME === 'undefined') ? '' : IDLE_NAME; }
function idle_cfg24() { return (typeof IDLE_24H === 'undefined') ? false : !!IDLE_24H; }
function idle_cfgUS() { return (typeof IDLE_DATE_US === 'undefined') ? true : !!IDLE_DATE_US; }

var IDLE_GAMES = { LMU: 'LMU', IRacing: 'IRACING', AssettoCorsaCompetizione: 'ACC', Automobilista2: 'AMS2',
    RFactor2: 'RF2', AssettoCorsa: 'AC', AssettoCorsaEVO: 'AC EVO', F12024: 'F1 24', F12025: 'F1 25' };

// called every frame from an invisible item on the driving screens
function idle_track() {
    var now = Date.now();
    if (root['idT'] && now - root['idT'] < 1000) return false;
    root['idT'] = now;
    var pname = $prop(NANO_P + 'PlayerName');
    if (pname) root['idName'] = String(pname);
    if (!$prop('DataCorePlugin.GameRunning')) return false;
    var track = $prop(NANO_P + 'TrackName');
    if (!track) return false;
    lh_tick();
    var game = String($prop('DataCorePlugin.CurrentGame') || '');
    var best = nano_refSecs();
    if (!(best > 0)) best = nano_secs($prop(NANO_P + 'BestLapTime'));
    root['idLast'] = {
        track: String(track).toUpperCase(),
        car: String($prop(NANO_P + 'CarModel') || '').toUpperCase(),
        game: IDLE_GAMES[game] || game.toUpperCase(),
        best: best,
        laps: $prop(NANO_P + 'CompletedLaps'),
        cons: lh_consText()
    };
    return false;
}

function idle_name() {
    var n = String(idle_cfgName() || '').trim();
    if (!n) n = root['idName'] || 'DRIVER';
    return n.toUpperCase();
}

// shrink long names to fit: width of each capital in Barlow Condensed Black italic (em)
var IDLE_W = {'A':0.515,'B':0.469,'C':0.462,'D':0.469,'E':0.431,'F':0.419,'G':0.464,'H':0.471,'I':0.233,'J':0.456,'K':0.501,'L':0.433,'M':0.549,'N':0.512,'O':0.469,'P':0.467,'Q':0.459,'R':0.475,'S':0.449,'T':0.484,'U':0.467,'V':0.505,'W':0.698,'X':0.488,'Y':0.493,'Z':0.411,'0':0.445,'1':0.294,'2':0.449,'3':0.44,'4':0.514,'5':0.445,'6':0.446,'7':0.422,'8':0.438,'9':0.442,' ':0.194,'-':0.287,'.':0.239,"'":0.198};
function idle_nameSize(max, width) {
    var n = idle_name(), em = 0;
    for (var i = 0; i < n.length; i++) em += IDLE_W.hasOwnProperty(n.charAt(i)) ? IDLE_W[n.charAt(i)] : 0.5;
    if (em <= 0) return max;
    return Math.max(24, Math.min(max, 0.97 * width / em));
}

var IDLE_DAYS = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
var IDLE_MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

function idle_time() {
    var d = new Date(), h = d.getHours(), m = ('0' + d.getMinutes()).slice(-2);
    if (idle_cfg24()) return ('0' + h).slice(-2) + ':' + m;
    return ((h % 12) || 12) + ':' + m;
}

function idle_ampm() {
    if (idle_cfg24()) return '';
    return new Date().getHours() < 12 ? 'AM' : 'PM';
}

function idle_date() {
    var d = new Date(), day = IDLE_DAYS[d.getDay()], mon = IDLE_MONTHS[d.getMonth()];
    return idle_cfgUS() ? day + ' ' + mon + ' ' + d.getDate() : day + ' ' + d.getDate() + ' ' + mon;
}

function idle_has() { return !!root['idLast']; }
function idle_none() { return !root['idLast']; }
function idle_l() { return root['idLast'] || {}; }
function idle_trackText() { return idle_l().track || ''; }
function idle_carText() {
    var l = idle_l();
    return [l.car, l.game].filter(function (x) { return x; }).join('  ·  ');
}
function idle_bestText() { return nano_fmtLap(idle_l().best, '-:--.---'); }
function idle_lapsText() { var n = idle_l().laps; return typeof n === 'number' ? String(n) : '--'; }
function idle_consText() { return idle_l().cons || '--'; }
