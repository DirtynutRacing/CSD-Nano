// CSD Nano Dashes - idle screen settings (shown when no game is running)
// Edit with Notepad, save, then restart SimHub (or reload the dash).
// Each dash folder has its own copy: change it in the dashes you use.

// Your name, shown big. Leave empty ('') to use the driver name from the game
// (iRacing, LMU and others that send it) after your first session.
var IDLE_NAME = '';

// Clock: false = 12-hour (1:13 PM), true = 24-hour (13:13)
var IDLE_24H = false;

// Date: true = TUE NOV 17, false = TUE 17 NOV
var IDLE_DATE_US = true;
